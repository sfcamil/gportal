#!/bin/bash

# Sets script to fail if any command fails.
set -e

usage() {
echo "JasperReports Server hotfix deployment"
echo
echo "Arguments:"
echo " \$1 path to hotfix readme.txt file"
echo " \$2 directory for the root of the JasperReports Server WAR: tomcat/webapps/jasperserver-pro"
echo " \$3 backup directory for the original WAR. 'Nobackup' if not needed"
echo " \$4 Optional. 'deletePriorVersions'. Will delete files in the Deleted files section with the given root name"
echo
echo "Process:"
echo " Make a backup copy of that folder to a separate location."
echo " Delete the files listed in the section 'Deleted files' from the web application files structure."
echo " Extract files (with full paths) from the hotfix to the root web application folder."

echo " This script DOES NOT do the other installation steps:"
echo " Remove the application server's JSP cache ie."
echo "  For a Tomcat deployment on Windows, might be in: C:\apache-tomcat\work\Catalina\localhost\jasperserver-pro."
echo "  For a JBoss deployment, might be in C:\jboss\standalone\tmp\work\jboss.web\default-host\jasperserver-pro."
echo " Start the application server."
echo " Clear any client browser caches."
}

echo "Installing JasperReports Server hotfix"

################## Check parameters ##################
if (( $# < 3 )); then
    echo "Illegal number of parameters: $#. Need at least 3."
	usage
	exit 1
elif (( $# > 4 )); then
    echo "Illegal number of parameters: $#. More than 4."
	usage
	exit 1
fi

if [ ! -f "$1" ]; then
  echo "no file at $1"
  usage
  exit 1
fi

if [ ! -d "$2" ]; then
  echo "no directory at $2"
  usage
  exit 1
elif [ ! -f "$2/WEB-INF/applicationContext.xml" ]; then
  echo "no exploded JasperReports Server WAR at $2"
  usage
  exit 1
fi

deletePriorVersions=false

if [ $# -eq 4 ] ; then
    if [ "$4" != "deletePriorVersions" ] ; then
		echo "Invalid deletePriorVersions parameter: $4"
		usage
		exit 1
	fi
	deletePriorVersions=true
fi

################## Backup if specified ##################

if [ "$3" != "Nobackup" ] ; then
	if [[ ! -e $3 ]]; then
		mkdir -p $3
	elif [[ ! -d $3 ]]; then
		echo "$3 already exists but is not a directory" 1>&2
		usage
		exit 1
	fi
	if  [ ! -d "$3" ]; then
	  echo "no directory to back up to at $3"
	  usage
	  exit 1
	elif ! find -- "$3" -prune -type d -empty | grep -q . ; then
		echo "backup directory $3 is not empty"
		usage
		exit 1
	else
		echo "Backing up JasperReports Server WAR to $3"
		cp -R $2 $3
	fi
else
	echo "Skipping backup"
fi

################## deletePriorVersions if specified ##################
preamble=notyet
listingBugs=notyet
deletedFiles=notyet

if [ "$deletePriorVersions" = "true" ] ; then

while read -r line
do
	if [ -z "$line" ] || [ "$line" = "None" ] ; then
	  continue
	fi
	case "$line" in
		*"This hotfix should be applied"* | *"Build version"* )
			#This hotfix should be applied to JasperReports Server Pro version [7.2.0].
			#Build version [20200219_0635].
			preamble=true
			echo "$line"
			;;
		*"It addresses the following bug(s):"* )
			if [ "$preamble" = "true" ] ; then
				preamble=done
			fi
			listingBugs=true
			echo "$line"
			;;
		*"Added files:"* | *"Modified files:"*)
			listingBugs=done
			;;
		*"Deleted files:"* )
			deletedFiles=true
			echo "$line"
			;;
		*"Additional Notes:"* )
			if [ "$deletedFiles" = "true" ] ; then
				deletedFiles=done
			fi
			;;
		* )
			if [ "$listingBugs" = "true" ] ; then
				echo "$line"
			elif [ "$deletedFiles" = "true" ] ; then
				pathNoExtn="${line%.*}"
				extn="${line##*.}"
				# ls $2/$pathNoExtn*.$extn
				for file in "$2"/"$pathNoExtn"*."$extn"
				do
					[ -e "$file" ] || continue
					rm -v "$file"
				done
				#rm -vf "${2}/${pathNoExtn}*.${extn}"
			fi
			;;
	esac
done < $1
fi

################## Do adds and updates. Do deletes if not deletePriorVersions ##################
addedFiles=notyet
modifiedFiles=notyet
additionalNotes=notyet

while read -r line
do
	if [ -z "$line" ] || [ "$line" = "None" ] ; then
	  echo
	  continue
	fi
	case "$line" in
		*"This hotfix should be applied"* | *"Build version"* )
			#This hotfix should be applied to JasperReports Server Pro version [7.2.0].
			#Build version [20200219_0635].
			if [ "$preamble" = "notyet" ] ; then
				preamble=true
				echo "$line"
			fi
			;;
		*"It addresses the following bug(s):"* )
			if [ "$preamble" = "true" ] ; then
				preamble=done
				echo "$line"
			fi
			if [ "$listingBugs" = "notyet" ] ; then
			    listingBugs=true
			fi
			;;
		*"Added files:"* )
			if [ "$listingBugs" = "true" ] ; then
				listingBugs=done
			fi
			addedFiles=true
			echo "$line"
			;;
		*"Modified files:"* )
			if [ "$addedFiles" = "true" ] ; then
				addedFiles=done
			fi
			modifiedFiles=true
			echo "$line"
			;;
		*"Deleted files:"* )
			if [ "$modifiedFiles" = "true" ] ; then
				modifiedFiles=done
			fi
			if [ "$deletedFiles" = "notyet" ] ; then
			    deletedFiles=true
				echo "$line"
			fi
			;;
		*"Additional Notes:"* )
			if [ "$deletedFiles" = "true" ] ; then
				deletedFiles=done
			fi
			additionalNotes=true
			echo "$line"
			;;
		* )
			if [ "$listingBugs" = "true" ] || [ "$additionalNotes" = "true" ] ; then
				echo "$line"
			elif [ "$addedFiles" = "true" ] || [ "$modifiedFiles" = "true" ] ; then
				if [ "$addedFiles" = "true" ] ; then
					echo "adding: $line"
				else
					echo "modifying: $line"
				fi
				cp ./$line $2/$line
			elif [ "$deletedFiles" = "true" ] ; then
				if [ ! -f "$2/$line" ]; then
					echo "$line does not exist in JasperReports Server WAR"
				else
					rm -v $2/$line
				fi
			fi
			;;
	esac
done < $1

if [ "$additionalNotes" = "true" ] ; then
	additionalNotes=done
fi

echo "========================================"

if [ "$listingBugs" = "done" ] && \
	[ "$additionalNotes" = "done" ] && \
	[ "$addedFiles" = "done" ] && \
	[ "$modifiedFiles" = "done" ] && \
	[ "$deletedFiles" = "done" ] ; then
	echo "Hotfix readme processed successfully!"
else 
	echo "Hotfix readme NOT completely processed!"
	echo "Section statuses: notyet=Not seen, true=section in progress, done=done done!"
	echo -e "preamble:\t\t$preamble"
	echo -e "listingBugs:\t\t$listingBugs"
	echo -e "addedFiles:\t\t$addedFiles"
	echo -e "modifiedFiles:\t\t$modifiedFiles"
	echo -e "deletedFiles:\t\t$deletedFiles"
	echo -e "additionalNotes:\t$additionalNotes"
fi
