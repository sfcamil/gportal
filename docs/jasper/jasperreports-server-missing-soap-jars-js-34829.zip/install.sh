#!/bin/bash

./installFix.sh readme.txt $CATALINA_HOME/webapps/jasperserver-pro/ Nobackup 2>&1 | tee -a $CATALINA_HOME/webapps/jasperserver-pro/WEB-INF/logs/install.log
