This fix should be applied to JasperReports Server Pro versions [7.2.X, 7.5.X].

To apply:
* Stop the application server.
* Find the root web application folder (e.g. c:\apache-tomcat\webapps\jasperserver-pro\).
* Make a backup copy of that folder to a new, separate location.
* Delete the files listed in the section "Deleted files" from the web application files structure.
* Extract files (with full paths) from the zip to the root web application folder.

It addresses the following bug(s):
* JS-34829 [#case 01800114 +4] Exception java.lang.NoClassDefFoundError: org/apache/axis/AxisFault during server start up

Added files:
WEB-INF/lib/axis-1.4-JS-4.jar
WEB-INF/lib/axis-jaxrpc-1.4-JS-1.jar
WEB-INF/lib/axis-saaj-1.4.jar
WEB-INF/lib/wsdl4j-1.5.1.jar

Modified files:
None

Deleted files:
None

Additional Notes:

The exception related to bug JS-34829 is not critical - the JasperReports Server functionality is not affected.
This fix stops the exception being displayed.
